Synthetic sample for the Loupe demo - every name, number and address is invented.
